# ConnectNow
This is a WhatsApp-style chat application.